<?php
namespace progroman\CityManager\DatabaseFile;

/**
 * Class BaseCitiesUa
 * @package progroman\CityManager\DownloadFile
 * @author Roman Shipilov (ProgRoman) <mr.progroman@yandex.ru>
 */
class BaseCitiesUa extends BaseCities {
}