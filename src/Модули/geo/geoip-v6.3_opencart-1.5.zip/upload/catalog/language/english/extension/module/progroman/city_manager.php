<?php
$_['text_unknown'] = 'Unknown';
$_['text_zone'] = 'City:';
$_['text_search_placeholder'] = 'Search';
$_['text_choose_region'] = 'Choose city';
$_['text_search'] = 'Search:';
$_['text_your_city'] = 'Your city';
$_['text_guessed'] = 'Yes?';