<?php
$_['text_unknown']            = 'Не определен';
$_['text_zone']               = 'Ваш город:';
$_['text_search_placeholder'] = 'Введите название';
$_['text_choose_region']      = 'Выберите город';
$_['text_search'] = 'Поиск:';
$_['text_your_city'] = 'Ваш город';
$_['text_guessed'] = 'Угадали?';