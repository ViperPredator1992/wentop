<?php
spl_autoload_register(function($class) {
    if (strpos($class, 'progroman\\') === 0) {
        include_once(DIR_SYSTEM . 'library/' . str_replace('\\', '/', strtolower($class)) . '.php');
        return true;
    }

    return false;
});
